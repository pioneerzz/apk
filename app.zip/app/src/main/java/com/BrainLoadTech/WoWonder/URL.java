package com.BrainLoadTech.WoWonder;

public class URL {

    public static final  String url = "https://www.nostalgiacity..xyz/welcome" ;
}
